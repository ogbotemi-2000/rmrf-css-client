module.exports = {
    apps : [{
      script    : "api.js",
      instances : "max",
      exec_mode : "cluster"
    }]
  }